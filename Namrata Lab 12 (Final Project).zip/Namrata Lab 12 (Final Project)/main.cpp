//Program to develop a Flying Dog game.
//Namrata Upadhyaya Acharya
//Lab 12
//5/03/2024
//SPRING 2024

#include "SSDL.h"
#include<cmath>
#include<cstdlib>

constexpr int RADIUS = 20;
constexpr int SPEED = 1;
constexpr int MARGIN = 55;
enum class Direction { NOTHING, LEFT = -1, RIGHT = 1, UP = -2, DOWN = 2 };
enum { WINDOW_WIDTH = 1000, WINDOW_HEIGHT = 700 };

struct Point2D
{
    int x_ = 0, y_ = 0;
};

struct Object
{
    Point2D location_;
    Direction direction_;
    SSDL_Sprite sprite_;
};

//For dog and bomb
void initializeThing(Object& Dog, Object& Bomb);
void moveThing(Object& dog, Object& Bomb);
void moveBombs(Object& bomb, int bombSpeed);
void drawThing(Object& dog, Object& Bomb);
void keyDirection(Object& Dog);
void DogCollision(Object& Dog, Object Bomb);

int main(int argc, char** argv)
{
    SSDL_SetWindowTitle("Flying Dog Game. Hit Esc to exit.");
    SSDL_SetWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);
    SSDL_SetWindowPosition(100, 100);
    const SSDL_Image IMG = SSDL_LoadImage("media//homepage3.png");  //Loads the image
    SSDL_RenderImage(IMG, 0, 0, 1000, 700);                         //Displays the image
    SSDL_RenderDrawRect(430, 390, 150, 50);                         //Makes the first rectangle
    SSDL_SetRenderDrawColor(WHITE);                                 //Sets the color to white
    SSDL_RenderTextCentered("START GAME", 505, 407);                //Name of the box
    SSDL_RenderTextCentered("FLYING DOG GAME", 495, 277);
    SSDL_RenderTextCentered("INSTRUCTIONS:", 495, 307);
    SSDL_RenderTextCentered("Use the Left, Right, Up and Down arrow to move the dog in the way intended.", 505, 337);
    SSDL_RenderTextCentered("HINT: Save the dog from the bomb.", 515, 367);
    SSDL_Music music = SSDL_LoadMUS("media/Sakura-Girl-Daisy-chosic.com_.mp3");   //TO PLAY THE SONG
    SSDL_VolumeMusic(int(MIX_MAX_VOLUME * 0.50));
    SSDL_PlayMusic(music, SSDL_FOREVER);                                          //TO PLAY IT CONTINUOUSLY

    SSDL_WaitMouse();

    int x = SSDL_GetMouseX(); //gets the x position of mouse click
    int y = SSDL_GetMouseY(); //gets the y position of mouse click
    Object Bomb;

    bool isquit = false;

    do
    {
        if (430 < x && x < 578 && 389 < y && y < 438)    // comparing with respect to position of rectangle named "START GAME"
        {
            SSDL_SetWindowTitle("Flying Dog Game. Hit Esc to exit.");
            SSDL_SetWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);
            SSDL_SetWindowPosition(0, 0);                //To make the image appear at the left top.

            //Load the image
            const SSDL_Image SKY = SSDL_LoadImage("media/SKY.png");

            Object Dog;
            initializeThing(Dog, Bomb);
            drawThing(Dog, Bomb);
            constexpr int FRAMES_PER_SECOND = 70;
            SSDL_SetFramesPerSecond(FRAMES_PER_SECOND);

            bool gameOver = false;
            SSDL_SetSpriteLocation(Bomb.sprite_, Bomb.location_.x_, Bomb.location_.y_);
            while (!gameOver && SSDL_IsNextFrame())
            {
                SSDL_RenderImage(SKY, 0, 0);
                SSDL_SetSpriteLocation(Dog.sprite_, Dog.location_.x_, Dog.location_.y_);
                SSDL_SetSpriteLocation(Bomb.sprite_, Bomb.location_.x_, Bomb.location_.y_);
                SSDL_RenderSprite(Dog.sprite_);
                const int bombSpeed = 4;
                SSDL_RenderSprite(Bomb.sprite_);
                moveBombs(Bomb, bombSpeed);

                //input
                keyDirection(Dog);

                // Update things
                if (Dog.direction_ == Direction::RIGHT || Dog.direction_ == Direction::LEFT ||
                    Dog.direction_ == Direction::UP || Dog.direction_ == Direction::DOWN)
                    moveThing(Dog, Bomb);

                if (Bomb.direction_ == Direction::RIGHT || Bomb.direction_ == Direction::LEFT ||
                    Bomb.direction_ == Direction::UP || Bomb.direction_ == Direction::DOWN)
                    moveThing(Dog, Bomb);

                DogCollision(Dog, Bomb);
            }
            return 0;

        }

    } while (!SSDL_IsQuitMessage() && !isquit);

    return 0;
}

void initializeThing(Object& Dog, Object& Bomb)
{
    Dog.location_ = { SSDL_GetWindowWidth() / 20, SSDL_GetWindowHeight() / 2 };
    Dog.direction_ = Direction::RIGHT;
    Dog.sprite_ = SSDL_LoadImage("media/DOG.png");

    Bomb.location_ = { SSDL_GetWindowWidth() , SSDL_GetWindowHeight() / 2 };
    Bomb.direction_ = Direction::LEFT;
    Bomb.sprite_ = SSDL_LoadImage("media/BOMB.png");
}

// Updates dog's x position based on speed and current direction.
void moveThing(Object& Dog, Object& Bomb)
{
    if (Dog.direction_ == Direction::RIGHT)
    {
        Dog.location_.x_ += int(Dog.direction_) * SPEED;
    }

    else if (Dog.direction_ == Direction::LEFT)
    {
        Dog.location_.x_ += int(Dog.direction_) * SPEED;
    }

    else if (Dog.direction_ == Direction::UP)
    {
        Dog.location_.y_ += int(Dog.direction_) * SPEED;
    }

    else if (Dog.direction_ == Direction::DOWN)
    {
        Dog.location_.y_ += int(Dog.direction_) * SPEED;
    }
    if (Dog.location_.x_ < MARGIN)
    {
        Dog.location_.x_ = MARGIN;
    }
    if (Dog.location_.x_ > WINDOW_WIDTH - MARGIN)
    {
        Dog.location_.x_ = WINDOW_WIDTH - MARGIN;
    }
    if (Dog.location_.y_ < MARGIN)
    {
        Dog.location_.y_ = MARGIN;
    }
    if (Dog.location_.y_ > WINDOW_HEIGHT - MARGIN)
    {
        Dog.location_.y_ = WINDOW_HEIGHT - MARGIN;
    }
}
void moveBombs(Object& bomb, int bombSpeed)
{
    bomb.location_.x_ -= bombSpeed;
    SSDL_SetSpriteLocation(bomb.sprite_, bomb.location_.x_, bomb.location_.y_);
    if (bomb.location_.x_ <= 0)
    {
        bomb.location_.x_ = WINDOW_WIDTH;
        bomb.location_.y_ = rand() % +WINDOW_HEIGHT;
    }
}

void drawThing(Object& Dog, Object& bomb)
{
    SSDL_SetSpriteLocation(Dog.sprite_, Dog.location_.x_, Dog.location_.y_);
    SSDL_RenderSprite(Dog.sprite_);

    SSDL_SetSpriteLocation(bomb.sprite_, bomb.location_.x_, bomb.location_.y_);
    SSDL_RenderSprite(bomb.sprite_);
}

void keyDirection(Object& Dog)
{
    SDL_Event event;

    bool mouseClicked = false;                                 //To know if mouse was clicked.

    while (SSDL_PollEvent(event))
        switch (event.type)
        {
        case SDL_QUIT:        SSDL_DeclareQuit();
            break;
        case SDL_KEYDOWN:
            if (SSDL_IsKeyPressed(SDLK_ESCAPE)) SSDL_DeclareQuit();
            if (SSDL_IsKeyPressed(SDLK_RIGHT)) Dog.direction_ = Direction::RIGHT;
            if (SSDL_IsKeyPressed(SDLK_LEFT)) Dog.direction_ = Direction::LEFT;
            if (SSDL_IsKeyPressed(SDLK_UP)) Dog.direction_ = Direction::UP;
            if (SSDL_IsKeyPressed(SDLK_DOWN)) Dog.direction_ = Direction::DOWN;
        case SDL_MOUSEBUTTONDOWN: mouseClicked = true;
        }
}

void DogCollision(Object& Dog, Object bomb)
{
    {
        if (SSDL_SpriteHasIntersection(Dog.sprite_, bomb.sprite_))
        {
            SSDL_RenderClear();
            SSDL_Music music = SSDL_LoadMUS("media/boom.mp3");   //TO PLAY THE SONG
            SSDL_VolumeMusic(int(MIX_MAX_VOLUME * 0.50));
            SSDL_PlayMusic(music, 0);                            //TO PLAY IT CONTINUOUSLY

            const SSDL_Image FIRE = SSDL_LoadImage("media/spark.png");
            SSDL_RenderImage(FIRE, 0, 0, 1000, 700);             //Displays the image


            SSDL_Delay(500);
            const SSDL_Image IMG = SSDL_LoadImage("media//Gameover.png");
            SSDL_RenderImage(IMG, 0, 0, 1000, 700);              //Displays the image
            SSDL_RenderTextCentered("GAME OVER.", 505, 407);
            SSDL_RenderTextCentered("Better Luck Next Time :)", 515, 367);
            SSDL_WaitKey();
            exit(-1);
        }
    }
}